int main(void) {
    int x, y;

    if (x < y) {
	int a[10];
    } else {
	int a[20];
    }
}
