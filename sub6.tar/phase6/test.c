void main(void) {
	int a, b;
	
	a = 1;
	b = 0;
	
	putchar((b||a));
	putchar((b&&a));
}
